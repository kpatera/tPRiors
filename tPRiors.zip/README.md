# |tPRiors|

 |tPRiors|: Bayesian prevalence estimation with prior elicitation. Temporary link: https://kpateras.shinyapps.io/tPRiors/

The development of this application has been funded by the University of Thessaly through the H2020 EU project 6614 - «unCoVer: Unravelling Data for Rapid Evidence-Based Response to COVID-19». More details can be found in the upcoming manuscript. tPRiors: An R Shiny tool for generating prior and producing posterior distributions for disease prevalence"
