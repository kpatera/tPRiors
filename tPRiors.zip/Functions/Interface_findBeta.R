sidebarPanel(width = 4,
             hr(),
             h3("Set a prevalence prior"),
             hr(),
             sliderInput(inputId = "PriorMetric", 
                         label = paste("Specify your prior belief about the",input$ID_MeanMedianMode,"",input$ID_TrueApp,": "), 
                         min=0, max=1, value=0.6,step = 0.01),
             radioButtons(inputId = "lower.value", 
                          label=paste("Is the percentile the upper limit of the",input$ID_MeanMedianMode,"?"),choices=c("Yes","No"),
                          selected="No",inline = T),
             sliderInput(inputId = "Percentile1", 
                         label = paste("Specify the level of confidence that the true value of the",input$ID_MeanMedianMode,"is greater or lower than the percentile.value: "),
                         min=0, max=1, value=0.95,step = 0.01),
             uiOutput("sliders_fb"),
             div(style="display:inline-block;width:30%;text-align: left;",actionButton("buttonPriorReset", "Reset tPriors"),style=icon("check")),
             div(style="display:inline-block;width:30%;text-align: center;",actionButton("buttonPriorHelp1", "Example"),style=icon("check")),
             div(style="display:inline-block;width:30%;text-align: right;",actionButton("buttonPrior", "Set prior(s)!"),style=icon("check"))
             
)