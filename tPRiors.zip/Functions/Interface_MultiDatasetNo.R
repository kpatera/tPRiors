mainPanel(width=8,fluidRow(valueBoxOutput("Boxsetup3", width = 50)),
                     fluidRow(uiOutput("APar1_Plot_fb")
                              )
)